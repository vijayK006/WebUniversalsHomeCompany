// import { useEffect } from "react";

// const Preloader = () => {
//   useEffect(() => {
//     setTimeout(() => {
//       document.querySelector("body").classList.add("page-loaded");
//     }, 500);
//   }, []);

//   return (
//     <div className="preloader">
//       <div className="position-relative">
//         {/* <div className="container">
//           <div className="squarebox one" />
//           <div className="squarebox two" />
//           <div className="squarebox three" />
//           <div className="squarebox two" />
//           <div className="squarebox three" />
//           <div className="squarebox four" />
//           <div className="squarebox three" />
//           <div className="squarebox four" />
//           <div className="squarebox five" />
//   </div> */}
//   <img src="assets/img/newLogo/webGlob.gif" alt="logo" className="per-loaderWeb"/>        
      
//       </div>
//     </div>
//   );
// };
// export default Preloader;
